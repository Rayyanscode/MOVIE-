import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import Home from './Home';
import {Routes,Route} from "react-router-dom";
import SingleMovie from './SingleMovie'
import Error from './Error';
import "./App.css"

function App() {

  return(
    <>
    
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='movie/:id' element={<SingleMovie />} />
        <Route path='*' element={<Error />} />
      </Routes>
    
  


    </>
  )
  
}

export default App;

































































































































































































// let dataobj = [
//   {
//     name: "Men Shirt",
//     type:'men',
//     discpriton: "New Black Shirt For Men",
//     imge: "https://sc04.alicdn.com/kf/Hdae17163cb0a4c1fbb300cc754e19e81l.jpg",
//     price: "499",
//   },
//   {
//     name: "Men Shirt New",
//     type:'men',
//     discpriton: "New blue Shirt For Men",
//     imge: "https://ae01.alicdn.com/kf/HTB1ouCNMVXXXXaOXFXXq6xXFXXXj/New-Autumn-Fashion-Brand-Print-Shirts-Slim-Fit-Shirt-Men-Long-Sleeve-Cotton-Casual-Mens-Shirts.jpg",
//     price: "500",
//   },
//   {
//     name: "Men's Casual Shirt",
//     type:'men',
//     discpriton: " Shirt Cotton Long Sleeve Button ",
//     imge: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVFRgWFhYYGBgZGBoZGhgYGhgaGB4YHBkaHB4YGBocIS4lHB4rIRoYJzgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHxISHzYsJCs1NjY0NDQ0NDQ0NDQ0NDQ0NDQ0MTQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABAIDBQYHAQj/xABKEAACAQIDBQUDCAYIAwkAAAABAgADEQQSIQUxQVFhBhMicYEHkaEyQlKCkrHB0RRicqLC8CMkY3ODsrPxJVPhFTM0NXSTo7TS/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QAJREAAgICAQMFAQEBAAAAAAAAAAECEQMhMRITQQQiMlGBYXEU/9oADAMBAAIRAxEAPwDs0REAREQBERAEREAREQDyYLtjjjRwdVlYqxUIpG8FyFuOoBJ9JksbjqdFc1R1Qc2IF+g5noJzftz2kTFItKkGyq+cuwyhiAQMo328ROtuEvjg5SWtGWTIoJ72T+yq5aNNL3y00F+ZyAE/aDSftfZa1Bfcw3GaVsHa5pEBtVO/mOo/KdBo4hXQMrBlI0P8/dObNglCTvjwzrwZ45I2ufKNSbaL4c5X1A3GSB2spldd/Sx+6Ru11AspCA36Amct2phaiasp1NhMYxt0bylSs6HVxbYthRpLndzoLiwHNjwA3mdb2XghQo06Q3IgW/Mgan1Nz6z5j7KbWbB4qniMuYoxzLfLdWUqwvbk3vAn0H2a7Z4THC1KpapbWi9lqDnYXsw6qSJ0xgonJLJ1GyxES5UREQBERAEREAREQBERAEREAREQBERAKZTUcAEkgAbyTYepmodp+1hosaVEKXHymbUA23KOY036cLctExmPrVzmq1WaxvYnwg9F3D0E2hhlJWYTzxi6W2dH2n20wtG4DGq3KnqPtGy+4maltTtziamlJRRXmPE/2mFh6LfrNfqMWYs2rE3J4/7dJTOiOCKOWWeUuHR6Uq4hiSWd8tzcl3IHK9yd+4dZbegVYq1rjQ2IYX8xobay7TdlIZSQRfUGx1Fjr5Ej1lupcKcouQNBe1zwF+E2qjF7LW0MWiol7IEUhn4tdiwFuYuQN5PpMJgu2FdKh7o5Usbr4Tfk7XBFxyHO1+MtvsSvXbNWYKOCrrYdOH3zLYbZ1KlTankRg4XxsPGCGDaN1ta3WYTUp6rX9OmDhj3dv+E/Z/aym9N3xJsUF0WmdahvbIAfknjc6Wubaa6jtztRVr1AwVERRZUUZtP1mYXLcLi3SXsbs9c3droN55C/36bvOU0tgLcEm6j49JgsFO4o6f8ApuNSZiqVmBK7+K8R1HMSinQbNcXBBuCN4I4g8Jn22GuhUlWG4jX385k9jYGlnAxBYL4gSgHEmxJOoHod/rNOy/Jl3l4JHZ3t/jqFlZ+/QW8Na7MB+rUHiv8AtZh0nTdi+0DDVwA+ag/EPqt+jj+ILOQUaIA6kWMvou7ST2Isp35I+hKNZXAZWDKdxBBB8iJdnAcLjalA5qdR0P6pIv58/Kbp2W7fNfLiyCpNhVAAy/3gGmXqN3G+8ZTwyjxs2hnjLT0dLieT2Ym4iIgCIiAIiIAiIgCIiAeSHtTGCjRqVTuRWbzsLgep0kyaR7UdoZMOlEHWs4uP1Esx/eye+WjHqkkUnLpi2aFRxKFHd2LOz3Atck5W8TMfkjM1zbU2A5kR0rjl7rSMhl9KfEMVI1upsRbiDPQSPMb+ydWoMuTMMudA6g6XUkgH4GUFZcr4qpUy947PkBVS1r2JJ1IGp13mWybyVfkh14KZ7eV06RYhQLkmwHUyrEUCrshtdSVNjcXBsdeOsmxRZJlJa8uNKIsmjF1qLGrdVuugIuAAMo1OmvoeUlop428hf85eQ2c9R+EvHDtkznKFLFQLjNe1ybcBu385VaLNtkbJylD05IAnjiSQQ8tpQ7HgLy7UEtkSGSinFvaxRTbICwa1w+oIFvm7iD11kKiDcAkXY2JOgFzvJPCS6zWUzGVqkrwaLZ3jsNtMVsPkLZmoN3TN9JQAyP1zIyEnnebLOM+xnaOTFVqBOlSmHHLNTa1h1Ic/ZnZpwzVSZ3QdxR7ERKlhERAEREAREQBERAPJx/2m4rNjQt/DTpqtuTMSxPqCnunYJ87YqvUxGJqO/hepUYkMbZBewVrXsEUAHf8AJm2Be6zDO/bR5ntL+GqgmRmw3jZQwYKxGcfJIBtmB4g8OcofFKjBEFzxJnZZxONmZBlwCYbDbQzTIJiLybKtUTA1t388IvLIqSpqkEh3l/A45UJzIGvbxgKXS3FM4K/C/USA9SWWqXkNWE6PNp1GdwUzNrqxygkc2BOl7a6nfxl5A/zmvy04dJYpvZulpIS14SJcrLokrBpTJIe+7weLIhbk7WOUdfeQNRFvLTvDIWjzEAZju3ndrx4HjI7CU1qsgYnFWBkN0XirK8fXVQAbm5tp5GYqsnI6GRKmKLHXgbj32t8fhJ2XTpMlLqNenpMn2Jxfc7RwrX0NUIf8QGnr0u490+kZ8r5GQ96mpplX8irrlP2ivvn1FhqwdFdTdWUMD0IBHwMwyqmdOJ2i/ERMjQREQBERAEREAREQDwz5rxOMzM9Zybu7OeZZmLHy3zv3afHmhhK9VflJTYr+0RZf3iJ89Ck2hsGHI7v+hnRg8s58/KRYq7aJ0VMo89fOXEwrKneZ0IYXADHNYaHeACQSLqCSLjS2sk92jC2Wx4ggTE4mqad0DHIzZivDNuv/ADyHITSXUttmUel6SKsDiNSORJ/eM2P9KR8pRCnhAYZswLjey6DKDocuttdZrWyKVyzbr+EaA9TvmVosVNpbHdWymWuqkZdXhnkZKkvNTa27coY7r5TazW5ajXrNbMukod54DLTGeB5Fiit3sZep1JjMVWCkE6k6WHT/AHEyWHwzsBlF8z5BbeXsCAPO4tz15RZZxdFw1ZYq1pbZpHd4bISFSpMXicUviBF7qwHRiCAfj8BJGIqi0w2Ia5mOSWjoxx2W6JzHTjYfG8zWIdUUAkbpgaTFd2++kmNhWtmZtTMoSaTpGs4pvZeTEjUX0IsRzHI/zwn0J7NcZ3uzcPfeiml6U2KL+6FPrPnSphWUXPpO0ew7ElsLXQ/Mr5h0DIot70J9TKzba2Wx0uDp0REyNRERAEREAREQBERANU9pFbLs+tzbIo9ai3+F5xmgbG3A7uhnQva3toDusGAczWrs3DKCyBbcSSSemUc9NJFWn3AU3NTMQOCql0bOTxa+dQBwuTuUTrwKonHndyItewBJ3jlNZ2ixLazY6lUEHnNaxzakmTm4Iw8mewuGKYegzKCKqu41s1hUZLc7eAn60u0wW3DKo3k/nNu7b7JFDCbOB0CUO7cj6eRG08z3k09WZ+NkG5R+MnE7iiMqqTLyMDoNesyQxx7oUrAcC/zigbMqH9UOWbqcv0RICJbSXVmtGVlDSgJcgAgX0uSAPUncJceWm3SSESNs7MSm6KGWoGpq+bQqSzMPDzHhG+MPtOqiuqZfHbxEeIWDLdD80lXZSeTGRWbUeX4mVqbylF2yw+JYfKW3Uay09NnsEGYk2AG+5kqo15BqXQ5l9QNIkI0RNpYZ6VRka2ZSAcpuLkA7/WY+q2hNhu5TL4wGozVL5ixLNzzE3JsOsi4TB95Vp07fLqIh8mdV/inPNUdEHbJnbHYH6FiVpC+VqNKoL77lLN++r++MLhwTmY+Q6ToXtswirVwlcrcEVKT2te3hZbX0uLuRfiBNDqFPEyLYWCre1yAAMzW0DH5RtoCbCMJOYg4sd4zEfJTQefEzpPsOrZWxVI72FN16hS6t7syfanPXSyBRbXS/3mdB9nFKnRx1JUqK+fBuSQQRn7xMygjePASPIyckdNsjHLaSOwRETmOkREQBERAEREAREQDjftaAOMQWOYYdCtrXsalS4sSL7h8ZplF9LcfcfVTYj1E3b2u4c/pFNmGZXp2SyfJKscwLAgm+YHfNAqU3sBme3JajD4ML/GdcH7VRxzS6nZIqUS2rEIPpEiQsFQFbE0qK+LvHSlmFxo7BWI8gTrIlTKpuys37WUL6sM1/eJnfZxghV2lhwtQIyOanhU2KoMxRTxzC4N7AC+pNgaZJaL44UzrPtZwwbAqbfIrUyPIhkt5eKcrp06a0Q6t/Sd4FZOSZCQw5i+hPO07D7TR/w+qeTUj/APKg/GcXpjSXwcFM/wAvwlobyq0sIbSe+Hyojkr4y1lBuwC2uzD5t76c7E+fQc9EVhLbS+5EjsZDCLbb5WssVgTa1jrqL2v0vY285PoUV7tmL2YFQq21cm2Zr7gAPiRILtaLDm/nLDDgZedpHqPDIRGq0yl2U2kjsVT77aeFB/5yt9i7/wAEx+Lq30ma9l6X2rhuhqk+lCp+NpzZHrR041vZ1X2u7O73Z7uBdqDpVHlfK3oFcn6s4rgKvBvf+c+hu2pIwGKyrnJoVBl11BUgnTXQEnTlPnDDeIWLafqsub8rSuJ0XyqyRiqLufApKjiOMzfYHBvRxuHrMcoFQKV4kP4NenjmvOlIHwkjmGrAfBVMmbP2ymHr0XRSwStTqPqTmCMCVXNvPI87S8qptlIppqj6fiInMdIiIgCIiAIiIB5MN2uxjUcFiKiA5lpta3AnTN6Xv6TMzH7ew3e4avT+nRqL9pCBC5IfBwfAYwLTdGUsWPFrKp08YFrl9CPlAW3g8LSIBm69TIWEq5hfnrw48uUyB+Ted8TzpcmBx1KxJ3dRoZ1T2IbKy0q+JJUmo6010GYBLliTb5xcafqj05njxOyexwf8OHWtU+8D8Jz5lR14XZk/aQt9nV/8M+6tTnFUWdv7fgHZ+Iv9Ff8AOs4kikS/p+DL1HyX+Fay8W5+XulgS6s3OcNK8DiFpuGZFcDerbteIvcXHC4I5gyhpaeSyUXNo4jO5bM7jcC4UNa5IFlJAte2mmm4bpZRpbczxTrKlhXqAb55halPODUUsliDa+hI0YhSCwB1KggnnLOKTNrIYciUky8UMewzsfBv+YCE+qCAQPMXmz+yGnm2mh+jSqt8Av8AFNUq082o38puHsdfLtIA/PoVAvoyG4+ww98xycG+Pk77Pm3aOwEwz1aVXPnpuyqtrl1LL3dQEi2UrnJPNQN5NvpKcM7bYl/+1MRrfIaYUMAygdxTawVgRa7Md283lcW5UWyuo2ay+AYeE0sluDpdgOq6W4c5Hp4CmtWn3q+DvEzgEBSmdc4NtV8ObUTNCqWYsxLE6kkkk+pmK2k2l+s6JwVHNCbs+lcNXV0V0ZWRgCrKQykcCrDQiX5r/YI32dhf7lPumwTiZ3HsREAREQBERAEREA5n2j7E0XxbOjdyrIrMqICC5Z8z6mwuAugA1BPGUJ2DpBbGtUP7IQfeDNp221sR/hof3qn5Qr6Snemm1ZosEGlJo5/tXsLSynLWqgjcXCMPUKqn4zdPZfgmo4BUaxIqVdRuIznUe6Y3bVXKjeU2jsdTy4Kh1Uv9tmb+KIzlL5MTxxgl0ohe0ZC2z6yjiaf+qh/CcXwWNKI6Miuri1ze6MCCGUg6G49RccZ2j2iuBgalza7UwPPvFnHP0cEmxGu8aGd2Be39PPzupfh4gBGkqEsnDFDodJfQ3F7HzseG8/A+6bGBQ0oaXTLdRrSaCZEdtw4m4AsTc8BPQwsCPMes9dAd4vpuOsk4bBO4GQXu4pgcc7C4FhuuAfceUoX1RBd7GWcRQzC4kxkBGsitUCHQ36SGvslP6MczlTN59kqd5tJG/wCXhqhsP2lXX/3JrbU0qfJtfl+UyHYWq+G2jh2AIR3FF77itTw2P1ip81EwnFpG0GrPoycC7dtbauL86X/16U77OYdp+xa1toVKz1WCVEptkQANmC93bMbi1qYO75x5TKElF2zeUHNUjRUXS4mJ2idJ1pOx+FVbZXPnUb8LTWe0fZfDqhKZ1Nifllv815pL1cK8mcPRzu7R0j2evfZuEP8AZKPdcfhNkmI7L4IUMHh6S/MooD1OUFj5kkn1mXmLNhERAEREAREQBERANe7RpZ0bmGU+liPvaRUPhmR7Sr/RqfouD7ww/ETG4f5M556kdOP4mtdqHIQ+tp0fAYfu6VOmNyIq/ZUD8Jz7bVHM9Jfp1UX7TqPxnSpfFwyuZ7RoXtYxAFClTJtnqZj+yin+Jk905hSyVRyYcvvE3D2r4sNiqdM6inSzfWdjf4IvvmlMgGqixHKejiVRR5WZ3JnlXAv9IkS8MQ60sgUZtUz/ADu6LZzTHQuSxO/W26XqOMvvl1nQ6zWkzPqaMUlRl3g2khEzkAFRfS7EKo6sTuEkORIrIBciKoXZf2vgxRqZA+eyIS1rC7oGsOmvuIlnC4x0V1Q2DgBtNbC48J4GzOt+TsOMjO/En/YafhPL75UsRarMToZap4YsQLgXNrsQAOpJ3CS1S0qvKtWXToq2nsfuXVUfODTR8wFh4lvprqOIPWNnY3LicMHe6piKDMTwC1FJ9wvLdV2YWB6X6chIeNRQhFpWS1RaL91s+qprO2x/WAeBpoPcz/mJmtl1jUoUnbe9NGPmygn75ie0ItUpnmrD3Ff/ANThnwd2P5Fhz4Zp3aclgUX5TeFf2m0HxM2+p8maulLvcdh0/tA58kBf+Gc7VtI606TZ1CmlgAOAA90rnk9nWcIiIgCIiAIiIAiIgGN29TzUH6AN9khvuBmCwTXWbVVphlKncQQfIixmobNPDlcTHItpm+F6aLD0c+Kw4/tc32FL/wAM3mabhx/XMP8Atv8A6NSbLtnHjD0KlZtyIzW5kDQepsPWXx8Fc3P4cg7cYqnU2k1yci5EdlIv4R4iN+4kj6pmGxrJ3lQpbJnfJbdkznLbpa0gPi0d8xdc19c25r79dx46iSBhz806e+elBUqR5U+bZSQJ6DK+5I3kS7isKaeXNa7oHABvYMSADyOl7cLjjpLFSOTKHOk9ZpHrPDZKRaqAm1uHnb1sQbesrVbadBv6aS1n3SXhaSuWLvkVULE2uSQCQij6Tbhc/kaWX3VEdjKZTmnpMgAyLjRpr6yUDykbHG1ha5J0HEmVlwWjydw9lG3GxOCCuSXw7d0WPzlABQnqAcvXLfjM72iT/u25Fh7wD/DOV+yztB3OJGGNstYhTly5Qyo5zX3k5siCxscx6TrHaA+FB+v/AAn85x5FSZ24m20YrEtZJiOxtHPjnfhTpkfWdgB+6rSftZstMme+zjD2o1ap31KhA6qgsPiWmEFcjqm6gzdIiJ0HIIiIAiIgCIiAIiIB4ZpSjLVqDk7+7MZus0/adMpXa40bxA8Dff8AG8zyLVm2F+4qRlWvQY8XI8syMo+LCWvarXy7OqfrMin7V/vUSp6ZcAXtbiN/mOsxntFariNnsi08zhlZyv0FuSyDeTu8PInfuMY5eCcsW9o4XQqEacORsR7jJCYlhounQaD3c/KWUQjqOY/n8561QDcPUi3uBnQpNHM4p8oknEN9Jl03Xv8AfqJcOOfixJ6jf5yA6a2voTv6b/uld+vvHLQSVORV44vwTxtE8QDMlsnaVO7B6bZiAEqBRUyMdxNI+F79dRbS81x77r6W0tum6bCNQYOktNsjPXYOSQoIBBOY88uYDzEnuyI7MTA4sVWdiKdRtd4R9etsvGW61OqqZ2pOqiwLMrKNb23jof5Ilt9r4ltHrVCRpq7bx1B1kOtjKmpLuba6sT95juMntRJL4lgDdSLGx0Nwd+oIvPDi7DifL85lu2lAIaWUAAmtuAHzwRu6NNYaR3JDtRM5tLtK9RQiIKSADwJYJmG9wLDU9Sx36zAu7Ekk2J3m5J14Xi0oeQ5N8llFLgzvYzEBcbhsx0bE0LkndashF+Q0nX8X26w9fErRVKwy65sgynMFIuL5lIFwQVuDcGcb7L7DqYysEpiwWzM7C6qoPEfOJ3BeOvWdMXsecPnejULu9y3fZdXN7srKoy7zpY798yk48M1jGXyRkO0m2EaizI6su64N7HdY8j0M3Xsnhu7wdBbWPdhiOr+M/FjOF7G2Xizi1X+kwwrF0eqVOTulVmqgsRkcBQ2movbznZOw2Id6T3Z3RXtTLm7BLXCsbakKVv1kRik7RM5tpJo2qIiXMxERAEREAREQBERAPJhO0uHzIrgao2v7J0PxtM3LVenmVlPzgR7xaQ1aomLp2athmkPb+1P0bD1aml0QlQeLnRB6sQJTRqceI0M0b2m7RPgog/KIdh0W4X3ksfqTGKt0dc3UWzQr6ak358b85bZ+Ynt54TOk4i0y3tut/vK8h5/EzwrPIBUCw4/d+UzmzNqUlw/c1WdStYVVZVzKbKLKbG48Qv8Azpgs0SAZMrhR8mrXZeAFFM3qTUA+Ei444fIwpmuX4Z1phN4vfKxO6/raRWY7hKVEEmS29tw4kpankyFjq2a+cJ+qLfIv9aYrK3MecuQBALeQcyZWlIcpWCJVmkkG5+zXa3c4g0SbJWAA5B0uV94LDzyzo21sRlA66ThFOqVIZTZlIZTyYG4PoQJ1V9qfpFOg6/PUk9GHyl9GUic+VeTqwSvRVgsLWr1ahpBnCqVKjMBco/E+Aa5RYsCeRF507YuAFCitPiBdiOLHVj7/AIWmE9neHy4XPbWpUdvRTkH+T4za5eKpIxyO5M9iIlygiIgCIiAIiIAiIgCIiAaJtT+grutjlJzj9lr7ul8w9JxXtRtT9JxNSoPk3yJ+wug95u31p3f2iYX+qVK63z0adRgRvsV/AgHyvPnHLaVjGmzWU7ike3nuaUxaaGJVeLym0QSVRKYvAPSZ5BM8zQD2LTy8QD20Sm5i5gFV5svZXapRXpfXQ8r2DeQ0U+pmrsTNl9nGzzX2hRp/M8TPf6CjMR6kKv1pSStUWhLpdn0D2WwZpYSgjaMEBI4gt4iD5Xt6TMREkhuz2IiCBERAEREAREQBERAEREAxvaH/AMLiP7ir/ptPlWIkoHk9iJIPDERAPYiIBS08ERAKp7EQBBiIBbqTfvYn/wCYn/09T/NTiJDB9BRESAIiIAiIgCIiAf/Z",
//     price: "699",
//   },
//   {
//     name: "Men Shirt",
//     type:'men',
//     discpriton: "Mens Formal Shirts For Men Clothes",
//     imge: "https://static.fibre2fashion.com/MemberResources/LeadResources/1/2018/4/Seller/18147225/Images/18147225_0_shirts-for-men.jpg",
//     price: "750",
//   },
//   {
//     name: "Girl Shirt",
//     type:'women',
//     discpriton: "New White Shirt For Girls",
//     imge: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBEVEhUSERERERISGBESERERERERERARGBgZGRgYGBgcIS4lHB4rHxgYJjgmKzAxNTU1GiQ7QDs1Py40NTQBDAwMDw8PGBERGDEhGCExND81NDExMT8/PzQ1MTE0MT80PzExMTc0MT80NDExNDQ1NzYxNzExNDE/Oz89MTE/Nf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAABAECAwUGB//EAEMQAAIBAwICBwUFBQcCBwAAAAECAAMEERIhBTEGEyIyQVFhcYGRscFCUmKh0QcUI3KSFSQzgtLh8FPiJVRzg6Kywv/EABkBAQEBAQEBAAAAAAAAAAAAAAABAwIEBf/EAB4RAQEAAgIDAQEAAAAAAAAAAAABAhEDMQQSQSEF/9oADAMBAAIRAxEAPwDs3F5SQqr1ERn7oZgC24GfZkgZ9RMG4xajOa1PYhSMnIYkgDHqVI9oIlr/AIYlVss1Rcr1bqjKFq0850PkHbPlg7neY0+B0VGF16taVC5bLsUqGqq7jATUTsAOZ8d4DtS6pq2hnCsdOFPPtEqvxII90LPiFGodNOolRiA+FOTpIDA/BlPsIiV5wSi+N6lMjUQ1N9JLEghjkHJBGR4ZzNaHBKYbKvVWmTk26uFoltAp5wBq7oXbVjIBxAcqXtFdYarSU0wDUDOimmDyL5PZB9YU7mm7MiVEd0Cl0R1ZkDbqWAORkcohV4BRLmoHqK25p6WTFFiyMzICpySUXvahtsBNbHhKUX1I9QqKaUlpv1ZRUTGNJChs8+bHOT5DAOmEkyIEQkwgRIJgxitxWwIDBcRW8r4U4OIpYVGqVCDnQo3Gcbnly986bWVM80z7S36zHPnxxy9bG2PDlljvbJKa5U+Iwd99/OOoYk9Nc4xgjlz5Ta25kb/EyTyMbZNLfHyk3s0JMqDLTdgJMiSIEiAgJIECZMkCBgVJmWJo0pAjEiWhiBWEtiEDHEJMIETSnylMS68oFjKmSZUmBUyIEypMC0qTKNUmFSuBAvUqYnIvq+TpXcnYAeM6CWtaqQKaMQ2cOQVp489UOHcN0HW+7+WNl/3nHJnMZv67wwuV18bcNtNCYPebdj6+Uextk8vWYvWxy3Pn4CK11Lc8n2zyzhyzvtl+bem82OE1j+tKjAscEEjlg/lAHkfjEKlkDuNj4EbETFbt6Zw41pyz9ofrGXj5T9xu1x8jG3WU076NkZlwZz7a4VhqRgynkR9fWdG2pO6F1UlVOkkeeM/UfGbcXJuet7jDl49Xc6okiEkTZkJIkSRKjQSDJEgyKo0rLmUMqIhJhAiEmEDKBhCBE0WZy6wJMo0sTMnaBDtFnqiVuK2Jfg9p11Qlu4mMj7xPIeyBFvQqVTimuRyLHZR752rHgCLhqn8RvI9wf5fH3zsUaKqAFAAGwA2A9gmuIFKaY28JlWtEBNTTqLd7kQPM49YyBL58vfJZL2stnTjvYUG+xpP4dS/lymDcLpfeqD3r+k7D0Ad129Iu9MjmCPdA5w4bR+8596/6ZlccNtsbqX/mZsflOl1Z8AT7ATM14a7nt9hfixHyEDgW/DOsqdXSXq1+0yqFVF8SfP2eM9hbW6U0WmgwiAAA8yeZLeZJyTLUKKU10oMDxPiT5k+JljJMZLv6vtda+Frm1pucsMN95dj/ALzm1+Hum47a+Y5j2idkyMzpy86JIE697aAqXUYYDUccmXxPtnKxIJEgyYEQqpmc0MzlQQhCAQhCBlCAkwIkrIgIATMKrTRzFLh4Cdw2TPV9HrbRSQ+NTXUP5AfkBPJKpZgBzYgD2nYT6IKQQIo5Kukezb9IFrY5Wa6Jjwvdfj847ogL6YTR1lIFcSZZhKQLAwMgS0CpEqRNMQxAxMhRkgSXlrcZYQLv/iY8O6R6YxPPVkKsyn7JI+Bndz/Ez6iI8apYqahycA+8bH6QOdCEIFTMjNTMYEwkQgTCRCBnCEIESMy2JRoGbmIXDxqs059Q7wHeB0tdxTHk2o/5QW+YE93e7Y9BPI9Eqeaxb7q/mSPoDPXcS5fCBPCl7Pxj+mKcLHZ+Pzj0kClWZrzmlaZrzlFmXaYxpl290VkVYTQCZrNU8vHnjxxKipkiLG6p9YaWtOsCioaeoaxTLFQ+nnpyCM+cZUj0kC1XnNLXvCVuRuJNr3hCqZ3kccTNNG8jj4j/ALZLDczbia5oE+Wlvzx9YR5yBgZEoiYkzeLmAZhmRDECcyIYhArIhCAGUcy0zqGArXaImNXDRWB6jodT77ebKvwBP/6noeJ8vhOT0UTFJT95nb89P0nW4tyX2yUMcOHZH/PExyKWA7I9ixpiAMk4A3JOwAiDi8btKrlHo1OrqUySDpVldSV1qynGrIXAGoAEhuaic1avFNIXq7PXpXVUBrNTWoUZjhCQSgYKudWe1nGAZ5vifSm7valX+zqwtbC0P944g1IVmrOOSUaZHaySMAbnI3GQG9NwfpDTe2avXxbtQd6F0lRlY0rlCFZMr3iSV06RvqXAycSjscOoMi6KtdqlSpqfDlAzAEZYKOWAyAhTpG2MZlyJw+A9JalzfXNuKDUaNrSoEiqNNdqtQllJAY6VKY7JGoHng7Dl2nSetUr3yoqNTo1qdjZIQVard4YPqb7gKljgbIpPhuHX4he1XqG1tGCVFANzcsA6WiMMgBTs9VhuFOwGGbYgNwuhFilS9r3tDUbZEe0p3DsalbiFUujVa71DuygoFX7O2wGCJlUoPdg8Os6j/uis/wDafEdtVzUY5qUqZ5M7EnUR2VHZGwCl39oHEksOEtTtwKRcLaW6pkaAwOogjcEIH38yDAX6LVf3ziF7xIb0UA4faN4NSQ66jjwILaSD+Iiezp85y+jXCha2dvbYw1NF148ardpz/WzRg35LtTop1tRThzq0UaZ8nfB7W3dUMwyMgAgyB65HKUod4RatQuNJY1kNQAlESkEpE/ZVtRZvTIYewco3S7wgUcdpv5j8466aqRXzQj34idYdtvbOjS7oiDx8iaV00uy/dZh8DM4ExWNCKyglsSstmAYhDMIGUJBMIBMa02mFcwEbgzATSud5kBA97wBNNGmPwqfjv9Y9xXuKfUTOwQKAo+yAPgJrxIfw/eJL0GbXuj2D5Txf7UeJVilDhlrtX4ixps3gluMByfIHO/4Vae0oTjdIeiFveVadao9anUpq9LXRdVL0XBDIcg4BDMMjBwx3iDgcEoWwoo1NgvC+HBhRfn++3KEipctgdpVYMFx3nJIHZWI/s9orcXF9dVEdSt7WNKjUIIt6hADvoG3WYwurfAyAdzn0XEjRViukJZ8MprXemAAhqqhalTx5Iq68Ed56Z5rOd+zK0ZOHpVcYqXb1bqp6l2wp9hVVPvlGX7NadR7vjF04OmrdGkhIIyKTVNvcHQTgcJ6NXNdeKGnc1Leot1xGlQpoFTXVcIxLswJCsopqCukgM25DEH60LhNXV9YvWFNYp6l1mnnTq088Z2zyzMqggeZ6CcXp3NjTNOmlBqWaNagidWtGqneATwBzq9/mDPO9Nm/eeNcMsCeyhNzUHg25bSR56aB/rnf4f0dS34jWu6dbQl6oVrXTs1yMuXBH4VqHGObtvjaLXfROvU4wL8VFSgtDqiQW68MVZGFPHcJUntZ21HG/IPQV3aszIjFaKlleohKvUcbMiMN1AOQzjfOQMEEhihTVAqIqoigBVUBVUeAAHIQYomimuin2cU6YKr2EAGEXyAxy5bSVMBh+UzTmJq3KZLzkEXP+If8AL8hOhS7oiV0O2PUCO0eQiLXmuKpiq49c/EA/WJzp8dXFQHzUH8yJzZUTFsRiYQKS2ZGIYgTmEjEiBnIzJkQCL3BjEVuDAQq85rYU9VRF83T4ZGZk/OP8CTNdPTU3wU/XED29qJpe9z3r85W1k3R7I/mT5iS9DegY2DE6EaERXynjN6brrOF0G/vN7eXbXrIDm2s6NY0wz45M1OlSAB5j+YZ9P0kvf3ahbpROgNcWlsgUDV1YOoogIxqZUZR6sJ6G4UaiQACeZAAJx5nxnC6QcJ/eTbKyJUp0rmnWqo+MMgSonI8yGdTj0lR5+7L1bihV1dm6uadkHXIFekD112yHxpsaFKivmlNjuGybG5qC8FG2co9azo06Ld5aatXuHR9PIlKKNpztkqPGes41wM11tzRqLbva1BUpkU9SBdDUyoUEYwGyPAFRtF6XR9Ev2vVYYFtTtKdIA/w1RyxOc+QUD3+cDztXjNWpw8Xasev/AHK3Sk6DH98un6tiqjxDpTI221HzjvSJxb0bJUqXAFW7s6dV6ta5ZzRpFqtRirsSCer38wZW36L1UorSWtTdUvku1VldQLZHNRKORncPg5xjwnR6RdHGvlt0quiJQrpXcIagd0VWVkDAgqTq7w5QEuHh7i8a4IxStdaBtj1t2w0uqN4pSRnp55F6lQ+c9Is53AeHVLa3Fq7I6UCadu67M9AbprXAAcZIOOeM+MfQwG15TLxl05SrjeRV7obqfQ/8/ON0OQitcdlT6n/n5RigdoHL4+ncPo4+R/Wcaeg44uaYPkw+BBH6Tz7SoiYTeYGASIQgEIQgYQkEyMwAmLXBm5MVuGgJtOz0YTNR2+6mPeWH6Gcaei6Lps7eZRfgCfrA9PayLnkB+IfrL28zuD2lHqT8Af1ihmjGCdpjTEu5kgUuG3mamRXbeQhlGfH+PUrO362plmY6KdNe9Uc8h6DzPh6nAPy676bXzPr6/qcHK0xTxSHkrah2vXJz5Yn2M0VdCjoHRgVZHUMrKeYIOxE+f8V/Z4dZNrXVEOSKdZXY0/RXByV9CM+pmPLM7r1r6X8/l8XC5Tnk/erZuOKent2aoqAIaX/lxTPVkf8Aq6dWr8XL8PhPpvAeJpc26V6a1ERwGAqU2Rt/LPeH4hkHwM8Xw3oCquGuqwrKCD1NNClNvR2JJdfQac43yCRPoNuOyAMDGAANsCXimUl9qz87Px8spOCakneu2NxFl5xq4iiHeavCZpGTUG8pTM1ffeBLbp7CJvR5TBe43u+YmtE7SDPiq5ov6YPwInmmnrLhdVN181YflPJGURFyYxFjAMyZWEC0JWEDAypkmQYFGMUrmNOYnWMDGeq6Npijn7zsfyA+k8pPZ8ETFBPUE/Ek/WB2rblMa3+Ivsb6Ta1mDn+J7AfmJKHqcKvKFM7Qq8oHPqneQkKvOQkDrUOUxq8zL252mdfnKFn5xq3O0VfmIxbHaBW4iSd6O3MQU9qA0s0pnmJmnOSh3gbp3W90midpRT2W9kKTbQHF5TyNRcEjyJHwnrUM8zfpio4/ET8d/rAVipjUVMAhCEAhCEBcypgTKkwMqpilSM1GijwKie6sE00kHkiD8hPDIuSAPEgfGfQEGMDy2gOWsVZs1iPT6xu3iTbVz6qfmJKOghl6nKYod5sx2xCudV5yqS1TxlU8JUdK2O0rc85FsdpF2eRkGFfmvtm9sYrXbu+0Ta2aUaXXKc77U6F1OefGRTSHlLnnMaLbKZqxhF32Rj6D5iRbGVuGxTb10j8x+ki1MK6Czz/GFxVb10n8h+k9Ak4nHlxUU+aj8iZUcuLGMzCBSEkiRAIQhAVMyczQzFzAXqtMAZaqd5UQGLBM1aY/GnzE9ys8bwRM109NR+CmexXnAft4jfuqOrMQoLBMnYZbZR72wPfHreea6fuVtQF7z1Ken0K5fPxUQO/QMaK5+BE51jXDIr+Dqrj3jP1nRVpFKVE39sxCkTev3pXTCGbXlLV1GMH1lLY42mtYZEoQqJyHluJagDmQ3OXpwLVokw5iO1OUUbnIJo7KAfCMK4PjE1febU9zCo4jWA0U/GoXf3JpB/8AuJrbTy/Frv8A8Vo0/srS6sjyZ9b/AOieot4HQQzl9IE7h/nHynTpmI8dX+Gp8nHwIP8AtCOCYrGTFmlAZUmSTKwJhIhAVYxaqZu5itUwF2kqJVjLoNoHR4AR165IGz4z4nHL5z1qc/hPGcOTNVB+JT8Dn6T2ipJQ9QM8l0zra6iUhuKYLN/O2MD3AD+qeivahSk7gnKr2eXeOw/MieMKlmLMSWJySdySeZMobteJ1lpqihAECqDpJOAMDxxGP7YuvBwP/bT9IkiTTTILPf3DHJqt7gq/IQS6r/8AVqf1GQFlwsov+81TzqP7mI+Uzd3PN397t+sviGmQY6X++/8AW36y6Vaq92o4/wAxPzmmmQVhVWvrj/rP/wDE/SKVuIXOf8Vv6U/SNFJk9KBlT4jc5z1mfaiY+UbTjlZcHTTbH4WHyaL9XM3pwOTe3rtdfvLAataOVXlhcDSM/hGJ9Esa6uoZTlWAIPmDyngLmh6Ts9F6zLrTJwNLAHkOefpA9zSO2Ytxph1W53LLj1MvbODz5HlFOkCdwj8Y+UI4xijGMkxMmUGZOZEMwJhCEBRxFaqx9kmLpA5rrGLZez7zK1Kcas6fZ95gb8LKrVRm2A1b+RIIHznraDqcYIPsIM8qlOahRA9B0hbFIL95lHuGT8wJ5sJNCJAEggLLgQxJgEkCCiWlBJhJkUYhiEIEYlSsvDEIxZZm6RkiVZYUhUpxjhaaan8wI+v0mjU5KJA9JZv2R6SnG6yGmgDAsGyVBBIGDn6TioJJMCsVMaiplQQhCAQhCBBmbwhAWab23d98IQGFloQgEiEJFTJhCVFlkwhIqRJEIQCEISxBCEIBCEJBBkiEIVZYGEIERUyYSoiEIQCEIQP/2Q==",
//     price: "799",
//   },
//   {
//     name: "Girl Jeans Shirt",
//     type:'women',
//     discpriton: "Jeans Shirt High Quality",
//     imge: "https://static-01.daraz.pk/p/95fd1da70adfa68fd1c41963e59ce4f9.jpg_340x340q80.jpg_.webp",
//     price: "900",
//   },
//   {
//     name: "woman Casual Shirt",
//     type:'women',
//     discpriton: " Women Printed Stylish Full Sleeve ",
//     imge: "https://ae01.alicdn.com/kf/H8e1ce2d324bb4fb79396a7d4b6b704fd6.jpg_q50.jpg",
//     price: "999",
//   },
//   {
//     name: "New Girl Shirt",
//     type:'women',
//     discpriton: "shirts are designed for formal, casual",
//     imge: "https://cdn.shopsy.pk/images/telemart/9d6ba333-c9ab-e159-3c25-1f3c594c93a4/c5dd4933d8cc058733aff1f40d5086a0e81ab9f2_masonry.jpg",
//     price: "550",
//   },
//   {
//     name: "Children Shirt",
//     type:'kids',
//     discpriton: "casual t-shirt for children",
//     imge: "https://cdn.boutiquetshirt.net/image/2021/09/28/minnie-mouse-im-not-yelling-im-a-cardinals-girl-shirt-classic-mens-t-shirt.jpg",
//     price: "499",
//   },
//   {
//     name: "kid Print  Shirt",
//     type:'kids',
//     discpriton: "Print t-shirt for kids ",
//     imge: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTn8Qsr1ZH9vWV4dmyn5hkxs_KsCeMVbYMhlw&usqp=CAU",
//     price: "900",
//   },
//   {
//     name: "Kid Casual Shirt",
//     type: "kids",
//     discpriton: "Bon Organik Beach Please Tshirts for  Boys",
//     imge: "https://m.media-amazon.com/images/I/51DXEXhVl0L._UL1000_.jpg",
//     price: "999",
//   },
//   {
//     name: "Kid t-shirt",
//     type: "kids",
//     discpriton: "Powerpuff - Kids The Holi Crew T-Shirts",
//     imge: "https://m.media-amazon.com/images/I/51nLxOlFFkL._SL1000_.jpg",
//     price: "550",
//   },


// ]



// function App() {

//  const [val,setVal] = useState(dataobj)

//  let changeVal = (e) =>{
//    let x = e.target.value

//    x === 'all items'?setVal(dataobj):setVal(dataobj.filter(y=>y.type === x ))
//  }





//   return (
//     <div className="container">

//       <div>
//         <h2 className='text-center bg-black text-white m-3'>UNIQUE STORE</h2>
//       </div>

//     <select name="" id="" onChange={(e)=>changeVal(e)} style={{marginTop:"50px", border:"5px solid"}}>
//       <option value="all items">All items</option>
//       <option value="men">Men</option>
//       <option value="women">Women</option>
//       <option value="kids">kids</option>
//     </select>




// <div className="d-flex justify-content-around align-items-center flex-wrap">

//     {
//       val.map((a,b)=>{
//         return <Second src={a.imge} title={a.name} discpriton={a.discpriton} price={a.price} key={b} />
//       })
//     }



// </div>

//           </div>
//   );
// }

// export default App;
