// context(Warehouse)
// Provider (delivery boy)
// consumer ==> (usecontexthook)


//   we need to create a context
import React, { useContext, useEffect, useState } from "react";


const API_URL = `https://www.omdbapi.com/?apikey=${process.env.REACT_APP_API_KEY}`

const AppContext = React.createContext();


// we need to create a Provider


const AppProvider = ({children}) =>{

const [isLoading,setisLoading] = useState(true)
const [movie,setMovie] = useState([])
const[isError,setisError] = useState({show:"false", msg: ""})
const [query, setQuery] = useState("titanic")
const getMovies =async(url) =>{
    try{
        const res = await fetch(url)
        const data = await res.json();
        console.log(data)
        if (data.Response === "True") {
            setisLoading(false)
             setMovie(data.Search)
            
        }else{
            setisError({
                show:true,
                msg:data.error,
            })

        }

    }catch(error){
        console.log(error)
    }

}

    useEffect(()=>{
        getMovies(`${API_URL}&s=${query}`)

    },[query])
    

    return <AppContext.Provider value={{isLoading,isError,movie, query, setQuery}}>
        {children}
    </AppContext.Provider>

}

// global custom hook

const useGlobaLContext = () => {
    return useContext(AppContext)


}


export {AppContext, AppProvider,useGlobaLContext};