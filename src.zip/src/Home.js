import React, { useContext } from "react";
import Movies from "./Movies";
// import { AppContext } from "./Context";
// import { useGlobaLContext } from "./Context";
import Search from './Search'

const Home=()=>{
    // const name = useContext(AppContext)
   
    return(
        <>
        <Search />
        <Movies />
            
        </>
    )
}

export default Home;


































































// const Second=({src,title,discription,price}) =>{
// return(
//     <>
// <div>
//     <img src={src} />
// </div>
// <div>
//     {title}
// </div>
// <div>
//     {discription}
// </div>

// <div>
//     {price}
// </div>

//     </>
// )
// }


// export default Second;