import React from 'react'
import { useGlobaLContext } from './Context'

const Search = () => {
  const {query, setQuery,isError} = useGlobaLContext();
 
  return (
    <>
    <section className='search-section'>
    <h2>search Your Favourite Movie</h2>
    <form action="#" onSubmit={(e) => e.preventDefault()}>
    <div>
      <input placeholder='search here' value={query} onChange={(e) => setQuery(e.target.value)} />
    </div>
    </form>
    <div className='card-error'>
      <p>{isError.show && isError.msg}</p>

    </div>

  </section>
  </>
  )
}

export default Search